﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerCtrl : MonoBehaviour
{
	public enum eState
	{
		Ready, 
		Move, 
		Attack, 
		Attack1,
		DIE  
	}

	private IStateMachine<PlayerCtrl> m_sm;
	private Dictionary<eState, IState<PlayerCtrl>> m_states = new Dictionary<eState, IState<PlayerCtrl>>();
	public static PlayerCtrl instance = null;
	//스텟
	public float maxhp = 100.0f;
	public float hp = 100.0f; //HP
	//컴포넌트
	private new Rigidbody rigidbody;
	[HideInInspector]public PlayerAnim playerAnim;
	private Animator animator;
	//공격
	public GameObject Cur_AttackColl;//기본공격
	public GameObject Skill_AttackColl;//스킬공격
	[HideInInspector]public float Attack1Cooltime = 5f;
	//플레이어 애니메이션

	//플레이어 속도
	private float walkSpeed = 4f; //걷기 속도
	private float runSpeed = 14f; //뛰기 속도
	private float anySpeed; //속도 변경

	//기타
	[SerializeField]
	private new Transform camera; //카메라
	public GameObject[] Effect;

	//UI
	public Slider hpSlider;

	private void Awake() //싱글톤
	{
		if(instance == null)
			instance = this;
		else if(instance != this)
			Destroy(this.gameObject);
	}
	private void Start()
	{
		m_states.Add(eState.Ready, new IStatePlayerReady());
		m_states.Add(eState.Move, new IStatePlayerMove());
		m_states.Add(eState.Attack, new IStatePlayerAttack());
		m_states.Add(eState.Attack1, new IStatePlayerAttack1());
		m_sm = new IStateMachine<PlayerCtrl>(this, m_states[eState.Ready]);

		rigidbody = GetComponent<Rigidbody>();
		playerAnim = GetComponent<PlayerAnim>();
		animator = GetComponent<Animator>();

		anySpeed = walkSpeed;
		hpSlider.maxValue = hp;
	}
	public void ChangeState(eState state) //스테이트 체인지
	{
		Debug.LogWarning(state);
		m_sm.SetState(m_states[state]);
	}
	private void FixedUpdate()
	{
		m_sm.OnFixedUpdate();
	}
	private void Update()
	{ 
		m_sm.OnUpdate();
		Attack1Cooltime += Time.deltaTime;
		hpSlider.value = hp;
	}
	public void DoMove() //Move 처리
	{
		float h = Input.GetAxis("Horizontal");
		float v = Input.GetAxis("Vertical");
		Vector3 moveH = transform.right * h;
		Vector3 moveV = transform.forward * v;
		Vector3 velocity = (moveH + moveV).normalized * anySpeed;
		rigidbody.MovePosition(transform.position + velocity * Time.deltaTime);
		transform.rotation = Quaternion.Euler(0,camera.eulerAngles.y,0);
		playerAnim.OnMovement(h, v);
		if (Input.GetKey(KeyCode.LeftShift))
			anySpeed = runSpeed;
		if (Input.GetKeyUp(KeyCode.LeftShift))
			anySpeed = walkSpeed;
		if (Input.GetKeyDown(KeyCode.Q))
			ChangeState(eState.Attack);
		if (Input.GetKeyDown(KeyCode.E) && Attack1Cooltime >= 4f)
			ChangeState(eState.Attack1);
	}
	public void ChangeMove() // Move로 변경
	{
		ChangeState(eState.Move);
	}
	public bool AnimEndCheck(string Anim)
	{
		return animator.GetCurrentAnimatorStateInfo(0).IsName(Anim) && animator.GetCurrentAnimatorStateInfo(0).normalizedTime >= 0.99f;
	} //애니메이션 끝나는거 체크
	public bool AnimEffectCheck(string Anim, float sce)
	{
		return animator.GetCurrentAnimatorStateInfo(0).IsName(Anim) && animator.GetCurrentAnimatorStateInfo(0).normalizedTime <= 0.99f && animator.GetCurrentAnimatorStateInfo(0).normalizedTime >= sce;
	} //애니메이션 이펙트 체크
	public void TakeDamage(float damage) //데미지 체크
	{
		playerAnim.OnHit();
		hp -= damage;
		Debug.Log("Player:hp" + hp);
	}
}
