﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FireBallEffect : MonoBehaviour
{
	private Rigidbody rb;
	public float speed = 1000f;
	public GameObject Effect;
	private void Start()
	{
		rb =  GetComponent<Rigidbody>();
		Destroy(this.gameObject, 3f);
	}
	private void Update()
	{
		rb.AddRelativeForce(Vector3.forward * speed * Time.deltaTime);
	}
	private void OnTriggerEnter(Collider other)
	{
		if (other.CompareTag("PLAYER"))
		{
			other.GetComponent<PlayerCtrl>().TakeDamage(10); //공격
			GameObject end = Instantiate(Effect, other.transform.position, Quaternion.identity);
			Destroy(this.gameObject);
		}
	}
}
