﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossAttackCollsion : MonoBehaviour
{
	private void OnTriggerEnter(Collider other) //공격처리
	{
		this.gameObject.SetActive(false);
		if (other.CompareTag("PLAYER"))
		{
			other.GetComponent<PlayerCtrl>().TakeDamage(10); //공격
		}
		Debug.Log("확인");
	}
}
