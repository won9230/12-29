﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerUI : MonoBehaviour
{
	Slider slHp;
	public GameObject fillArea;
	public PlayerCtrl player;

	private float maxHp;
	private float curHp;
	private void Start()
	{
		slHp = GetComponent<Slider>();
		player = GetComponentInParent<PlayerCtrl>();
		maxHp = player.maxhp;
		curHp = player.hp;

		slHp.value = (float)curHp / (float)maxHp;
	}
	private void Update()
	{
		if (slHp.value <= 0)
			fillArea.SetActive(false);
		else
			fillArea.SetActive(true);
		HandleHp();
	}
	private void HandleHp()
	{
		slHp.value = (float)curHp / (float)maxHp;
	}
}
