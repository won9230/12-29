﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BossUI : MonoBehaviour
{
    Slider slHp;
    public GameObject fillArea;
    public BossCtrl boss;

    float maxHp;
    float curHp;


    void Start()
    {
        slHp = GetComponent<Slider>();
       boss = GetComponentInParent<BossCtrl>();
        maxHp = boss.maxhp;
        curHp = boss.hp;

        slHp.value = (float)curHp / (float)maxHp;
    }


    void Update()
    {
        if (slHp.value <= 0)
            fillArea.SetActive(false);
        else
            fillArea.SetActive(true);
        HandleHp();
    }
    private void HandleHp()
    {
        slHp.value = (float)curHp / (float)maxHp;
    }
}
