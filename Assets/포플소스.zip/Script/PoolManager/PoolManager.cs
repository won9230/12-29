﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ObjectPooling.Multi {
	[System.Serializable]
	public class ObjectPool
	{
		public GameObject prefab;
		public int size;
	}
	public class PoolManager : MonoBehaviour
	{
		public List<ObjectPool> ObjectPoolList;

		private Dictionary<string, Queue<GameObject>> objectPoolDictionary;

		#region SingleTone
		private static PoolManager _instance = null;

		public static PoolManager Instance
		{
			get
			{
				if (_instance == null)
				{
					_instance = (PoolManager)FindObjectOfType(typeof(PoolManager));
					if (_instance == null)
					{
						Debug.Log("There's no active Singletone object");
					}
				}
				return _instance;
			}
		}
		private void Awake()
		{
			if(_instance != null && _instance != this)
			{
				DestroyImmediate(gameObject);
			}
			else
			{
				_instance = this;
			}
		}
		#endregion

		GameObject CreateGameObject(GameObject prefab)
		{
			GameObject obj = GameObject.Instantiate(prefab);
			obj.name = prefab.name;
			obj.SetActive(false);
			obj.transform.parent = this.transform;
			return obj;
		}

		private void Init()
		{
			objectPoolDictionary = new Dictionary<string, Queue<GameObject>>();
			foreach(ObjectPool pool in ObjectPoolList)
			{
				if (!pool.prefab)
				{
					Debug.LogError("invalid prefab");
					continue;
				}

				Queue<GameObject> poolQueue = new Queue<GameObject>();
				for(int i = 0; i<pool.size; i++)
				{
					poolQueue.Enqueue(CreateGameObject(pool.prefab));
				}
				objectPoolDictionary.Add(pool.prefab.name, poolQueue);
			}
		}

		public GameObject Spawn(string poolName, Vector3 position, Quaternion rotation)
		{
			GameObject obj = null;

			if (objectPoolDictionary.ContainsKey(poolName))
			{
				Queue<GameObject> poolQueue = objectPoolDictionary[poolName];

				if(poolQueue.Count > 0)
				{
					obj = poolQueue.Dequeue();
				}
				else
				{
					Debug.Log(poolQueue + "object pool is empty");
				}

				if(obj != null)
				{
					obj.transform.position = position;
					obj.transform.rotation = rotation;
					obj.SetActive(true);
				}
			}
			else
			{
				Debug.LogError(poolName + "onject pool is not available");
			}
			return obj;
		}
		private IEnumerator _despawn(GameObject poolObject, float timer)
		{
			yield return new WaitForSeconds(timer);

			if (objectPoolDictionary.ContainsKey(poolObject.name))
			{
				Queue<GameObject> poolQueue = objectPoolDictionary[poolObject.name];

				if(poolQueue.Contains(poolObject) == false)
				{
					objectPoolDictionary[poolObject.name].Enqueue(poolObject);
					poolObject.SetActive(false);
				}
				else
				{
					Debug.LogWarning($"Already despawn{poolObject.name}");
				}
			}
			else
			{
				Debug.Log(poolObject.name + " object pool is not available");
			}
		}
		public void Despawn(GameObject poolObject, float timer = 0f)
		{
			StartCoroutine(_despawn(poolObject, timer));
		}
	}
}
